-- MySQL dump 10.16  Distrib 10.2.31-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u117204720_organizer
-- ------------------------------------------------------
-- Server version	10.2.31-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_type`
--

DROP TABLE IF EXISTS `event_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_type` (
  `event_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type_desc` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`event_type_id`),
  KEY `event_type_id` (`event_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_type`
--

/*!40000 ALTER TABLE `event_type` DISABLE KEYS */;
INSERT INTO `event_type` VALUES (1,'Programming'),(2,'Chores'),(3,'Driving'),(4,'Eating'),(5,'Leisure'),(6,'Entertainment'),(7,'Gaming'),(8,'Church'),(9,'Hangout'),(10,'Sleeping');
/*!40000 ALTER TABLE `event_type` ENABLE KEYS */;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `title` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL,
  `expense` float(5,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`event_id`),
  KEY `event_id` (`event_id`),
  KEY `type` (`type`),
  CONSTRAINT `events_ibfk_1` FOREIGN KEY (`type`) REFERENCES `event_type` (`event_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (2,'2020-02-11 00:12:00','2020-02-11 04:35:00','Eating','',4,50.00),(5,'2020-02-11 01:00:00','2020-02-11 02:00:00','test','test',1,0.00),(6,'2020-02-12 00:00:00','2020-02-12 15:00:00','testing','testing',1,0.00),(7,'2020-02-11 01:00:00','2020-02-11 02:00:00','Sleeping','asdfasdf',10,0.00),(8,'2020-02-12 22:00:00','2020-02-12 23:00:00','Eating','Dinner',4,500.00),(9,'2020-03-03 13:30:00','2020-03-03 15:30:00','testing','',1,999.99),(10,'2020-03-13 17:00:00','2020-03-13 23:00:00','Programming','Presentation Preparation',1,0.00),(11,'2020-03-13 13:00:00','2020-03-13 17:00:00','Sleeping','',10,0.00),(12,'2020-03-13 12:00:00','2020-03-13 13:00:00','Lunch','',4,70.00),(13,'2020-03-13 11:00:00','2020-03-13 12:00:00','Data Science Tr','',1,0.00),(14,'2020-03-13 11:00:00','2020-03-13 07:00:00','Hacking Course','Scanning Networks',1,0.00);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;

--
-- Dumping routines for database 'u117204720_organizer'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26  8:19:08
